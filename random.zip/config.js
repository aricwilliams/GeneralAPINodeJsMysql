const config = {
  db: {
    /* don't expose password or any sensitive info, done only for demo */
    host: "mi3-tr100.supercp.com",
    user: "aricwill_masterdude",
    password: "Maytheforcebewithyou12!",
    database: "aricwill_roomiehavenapi",
  },
  listPerPage: 10,
};
module.exports = config;
